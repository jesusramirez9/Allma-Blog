<div class="form-group">
    <?php echo Form::label('name', 'Nombre:'); ?>

    <?php echo Form::text('name', null, ['class' => 'form-control', 'placeholder' => 'Ingrese el nombre de la persona']); ?>


    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <small class="text-danger"><?php echo e($message); ?></small>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

</div>

<div class="form-group">
    <?php echo Form::label('occupation', 'Ocupación:'); ?>

    <?php echo Form::text('occupation', null, ['class' => 'form-control', 'placeholder' => 'Ingrese la ocupación de la persona']); ?>


    <?php $__errorArgs = ['occupation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <small class="text-danger"><?php echo e($message); ?></small>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-group">
    <p class="font-weight-bold">Estado</p>
    <label class="mr-3">
        <?php echo Form::radio('status', 1, true); ?>

        Activado
    </label>
    <label>
        <?php echo Form::radio('status', 2); ?>

        Desactivado
    </label>

    <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <br>
        <small class="text-danger"><?php echo e($message); ?></small>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="row mb-3">
    <div class="col-md-3">
        <div class="image-wrapper">
            <?php if(isset($testimonial->image)): ?>
                <img id="picture" src="<?php echo e(Storage::url($testimonial->image->url)); ?>" class="img-fluid">
            <?php else: ?>
                <img id="picture" src="https://cdn.pixabay.com/photo/2020/11/07/10/36/motorcycle-5720553_960_720.jpg" class="img-fluid">
            <?php endif; ?>
        </div>

    </div>
    <div class="col-md-3">
        <div class="form-group">
            <?php echo Form::label('file', 'Seleccione la imagen de la persona'); ?>

            <?php echo Form::file('file', ['class' => 'form-control-file', 'accept' => 'image/*']); ?>


            <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="text-danger"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

    </div>
</div>

<div class="form-group">
    <?php echo Form::label('message', 'Testimonio:'); ?>

    <?php echo Form::textarea('message', null, ['class' => 'form-control', 'rows' => 3]); ?>


    <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <small class="text-danger"><?php echo e($message); ?></small>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<?php /**PATH D:\Proyectos\freelance\Allma-Blog\resources\views/admin/testimonials/partials/form.blade.php ENDPATH**/ ?>