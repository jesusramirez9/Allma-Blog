
<?php $__env->startSection('content'); ?>
    <div id="carouselExampleSlidesOnly" class=" slide" data-bs-ride="carousel">
        <div class="carousel-inner">
            <div class="carousel-item imgslide1 active"
                style="background-image: url('<?php echo e(asset('images/blog/slider.png')); ?>')">
                <div class="container">
                    <div class="centrado contac_txt">
                        <h1 class="txtcontc1">Blog</h1>
                        <p class="txtcontc2">Consejos y noticias</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="indx-blg">
            <p class="m-0 fw600">Mantente enterado de todo</p>
            <p class="bluzol">Acerca de una vida más feliz</p>
        </div>
        <div class="row mrowblg">
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-12 col-md-6 mt-4  position-relative">
                    <div class=" shadow mrl bg-nrpte bg-cover  bg-body h-sda  bg-center"
                        style="background-image: url(<?php if($post->image): ?> <?php echo e(Storage::url($post->image->url)); ?> <?php else: ?> https://cdn.pixabay.com/photo/2020/11/07/10/36/motorcycle-5720553_960_720.jpg <?php endif; ?>)">

                        <div class="fondo_graybajo position-absolute">
                            <div class="p-2">
                                <h1 class="mrgnt">
                                    <a class="rute_a" href="<?php echo e(route('posts.show', $post)); ?>">
                                        <?php echo e($post->name); ?>

                                    </a>

                                </h1>
                                <div class="txtsizesm mrgdas">
                                    Lorem ipsum dolor sit amet consectetur, adipisicing elit. Amet accusantium assumenda nam
                                    nobis cupiditate voluptatibus obcaecati rerum expedita illum maiores ea co </div>
                                <div class="text-black fw600 mrgdas txt_dte">
                                    12 mayo 19
                                </div>
                                
                            </div>
                        </div>



                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

    </div>

    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.webapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Proyectos\freelance\Allma-Blog\resources\views/posts/index.blade.php ENDPATH**/ ?>