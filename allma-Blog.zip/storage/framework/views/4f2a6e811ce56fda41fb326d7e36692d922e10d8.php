

<?php $__env->startSection('title', 'Allma'); ?>

<?php $__env->startSection('content_header'); ?>
<h1>Crear nuevo testimonio</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
        <?php echo Form::open(['route' => 'admin.testimonials.store', 'autocomplete' => 'off', 'files'=>true]); ?>


        <?php echo $__env->make('admin.testimonials.partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo Form::submit('Crear Testimonio', ['class' => 'btn btn-primary']); ?>


        <?php echo Form::close(); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    //cambiar imagen
    document.getElementById("file").addEventListener('change', cambiarImagen);

    function cambiarImagen(event) {
        var file = event.target.files[0];

        var reader = new FileReader();
        reader.onload = (event) => {
            document.getElementById("picture").setAttribute('src', event.target.result);
        };

        reader.readAsDataURL(file);
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Proyectos\freelance\Allma-Blog\resources\views/admin/testimonials/create.blade.php ENDPATH**/ ?>