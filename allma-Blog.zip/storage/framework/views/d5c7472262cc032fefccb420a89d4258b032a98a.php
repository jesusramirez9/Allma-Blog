

<?php $__env->startSection('title', 'Allma'); ?>

<?php $__env->startSection('content_header'); ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin.testimonials.index')): ?>
        <a class="btn btn-secondary float-right " href="<?php echo e(route('admin.testimonials.create')); ?>">Agregar Testimonio</a>
    <?php endif; ?>
    <h1>Lista de Testimonios</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(session('info')): ?>
        <div class="alert alert-danger">
            <strong><?php echo e(session('info')); ?></strong>
        </div>
    <?php endif; ?>
    <div class="card">

        <div class="card-body">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nombre</th>
                        <th>Estado</th>
                        <th colspan="2"></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($testimonial->id); ?></td>
                            <td><?php echo e($testimonial->name); ?></td>
                            <td><?php echo e($testimonial->status == 1 ? 'Activo':'Desactivado'); ?></td>
                            <td width="10px">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin.testimonials.edit')): ?>
                                    <a class="btn btn-primary btn-sm"
                                        href="<?php echo e(route('admin.testimonials.edit', $testimonial)); ?>">Editar</a>
                                <?php endif; ?>
                            </td>
                            <td width="10px">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin.testimonials.destroy')): ?>
                                    <form action="<?php echo e(route('admin.testimonials.destroy', $testimonial)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <button type="submit" class="btn btn-danger btn-sm">Eliminar</button>
                                    </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Proyectos\freelance\Allma-Blog\resources\views/admin/testimonials/index.blade.php ENDPATH**/ ?>